// var mongoose = require('mongoose');

// // Create dog schema and attach it as a model to our database
// var DogSchema = new mongoose.Schema({
//     name: String, // can add validations here
//     weight: Number,
//     color: String
// });

// // Mongoose automatically looks for the plural version of your model name, so a Dog model in Mongoose looks for 'dogs' in Mongo.
// var Dog = mongoose.model('Dog', DogSchema);

